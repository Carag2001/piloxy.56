import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

// ─────────────────────────────────────────────────────────────
// Rôles officiels de PILOXY 56 (cf. cahier des charges).
// Le Président possède toutes les permissions existantes.
// ─────────────────────────────────────────────────────────────
const ROLES = [
  { name: "Président", slug: "president", color: "#0C7C92", icon: "crown", order: 0, isSystem: true },
  { name: "Vice-présidente", slug: "vice-presidente", color: "#0C7C92", icon: "star", order: 1 },
  { name: "Responsable Activité", slug: "responsable-activite", color: "#1F8A5F", icon: "compass", order: 2 },
  { name: "Responsable Sécurité", slug: "responsable-securite", color: "#B45309", icon: "shield", order: 3 },
  { name: "Responsable Trésorerie", slug: "responsable-tresorerie", color: "#B45309", icon: "wallet", order: 4 },
  { name: "Responsable Communication", slug: "responsable-communication", color: "#7C3AED", icon: "megaphone", order: 5 },
  { name: "Secrétaire", slug: "secretaire", color: "#7C3AED", icon: "file-text", order: 6 },
  { name: "Animateur", slug: "animateur", color: "#1F8A5F", icon: "users", order: 7 },
  { name: "Membre Sécurité", slug: "membre-securite", color: "#B45309", icon: "shield", order: 8 },
  { name: "Membre Communication", slug: "membre-communication", color: "#7C3AED", icon: "megaphone", order: 9 },
  { name: "Bénévole", slug: "benevole", color: "#3FBE86", icon: "heart-handshake", order: 10 },
  { name: "Adhérent", slug: "adherent", color: "#0C7C92", icon: "user", order: 11 },
  { name: "Parent", slug: "parent", color: "#64748B", icon: "users", order: 12 },
  { name: "Partenaire", slug: "partenaire", color: "#64748B", icon: "handshake", order: 13 },
  { name: "Collectivité", slug: "collectivite", color: "#64748B", icon: "landmark", order: 14 },
  { name: "Visiteur", slug: "visiteur", color: "#94A3B8", icon: "eye", order: 15 },
];

const MODULES = [
  "users", "roles", "events", "activities", "documents", "gallery",
  "news", "partners", "finances", "incidents", "settings",
];
const ACTIONS = ["create", "read", "update", "delete", "export", "validate"];

async function main() {
  console.log("🌊 Seed PILOXY 56 — démarrage...");

  // Rôles
  const roleRecords: Record<string, string> = {};
  for (const role of ROLES) {
    const created = await prisma.role.upsert({
      where: { slug: role.slug },
      update: {},
      create: role,
    });
    roleRecords[role.slug] = created.id;
  }
  console.log(`✔ ${ROLES.length} rôles créés`);

  // Permissions (produit cartésien modules × actions)
  const permissionRecords: string[] = [];
  for (const module of MODULES) {
    for (const action of ACTIONS) {
      const perm = await prisma.permission.upsert({
        where: { module_action: { module, action } },
        update: {},
        create: { module, action, description: `${action} sur ${module}` },
      });
      permissionRecords.push(perm.id);
    }
  }
  console.log(`✔ ${permissionRecords.length} permissions créées`);

  // Le Président obtient toutes les permissions
  for (const permissionId of permissionRecords) {
    await prisma.rolePermission.upsert({
      where: { roleId_permissionId: { roleId: roleRecords["president"], permissionId } },
      update: {},
      create: { roleId: roleRecords["president"], permissionId },
    });
  }
  console.log("✔ Toutes les permissions assignées au Président");

  // Compte Président de démonstration
  const passwordHash = await bcrypt.hash("Piloxy56!2026", 12);
  await prisma.user.upsert({
    where: { email: "president@piloxy56.fr" },
    update: {},
    create: {
      firstName: "Président",
      lastName: "PILOXY 56",
      email: "president@piloxy56.fr",
      passwordHash,
      status: "ACTIVE",
      roleId: roleRecords["president"],
      badgeNumber: "P-0001",
    },
  });
  console.log("✔ Compte président créé (president@piloxy56.fr / Piloxy56!2026)");

  // Activité de démo
  const activity = await prisma.activity.upsert({
    where: { id: "seed-activity-barbecue" },
    update: {},
    create: {
      id: "seed-activity-barbecue",
      name: "Barbecue",
      description: "Moment convivial entre membres",
      color: "#F7C331",
    },
  });

  // Événement de démo
  const inThreeWeeks = new Date();
  inThreeWeeks.setDate(inThreeWeeks.getDate() + 21);

  await prisma.event.upsert({
    where: { slug: "barbecue-estival-2026" },
    update: {},
    create: {
      title: "Barbecue estival PILOXY 56",
      slug: "barbecue-estival-2026",
      description:
        "Rejoignez-nous pour notre traditionnel barbecue d'été : jeux, musique et bonne humeur au programme, ouvert à tous les adhérents et leurs familles.",
      location: "Base nautique de Hennebont",
      address: "Hennebont, Morbihan",
      startsAt: inThreeWeeks,
      capacity: 80,
      status: "PUBLISHED",
      activityId: activity.id,
      createdById: (await prisma.user.findUniqueOrThrow({ where: { email: "president@piloxy56.fr" } })).id,
    },
  });
  console.log("✔ Événement de démonstration créé");

  console.log("🌊 Seed terminé avec succès.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
