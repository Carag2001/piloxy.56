"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowRight, Sparkles } from "lucide-react";

export function Hero() {
  return (
    <section className="relative flex min-h-screen items-center overflow-hidden bg-gradient-aube pt-20">
      {/* Halo soleil */}
      <div className="pointer-events-none absolute -right-40 -top-40 h-[600px] w-[600px] rounded-full bg-gradient-soleil opacity-70" />
      {/* Vague de fond animée, évoquant la côte du Morbihan */}
      <svg
        className="pointer-events-none absolute inset-x-0 bottom-0 w-full animate-wave-drift text-ocean-100"
        viewBox="0 0 1440 320"
        fill="currentColor"
        aria-hidden="true"
      >
        <path d="M0,192L60,181.3C120,171,240,149,360,154.7C480,160,600,192,720,197.3C840,203,960,181,1080,165.3C1200,149,1320,139,1380,133.3L1440,128L1440,320L0,320Z" />
      </svg>

      <div className="container-page relative z-10 grid items-center gap-12 lg:grid-cols-2">
        <div>
          <motion.span
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="glass-card mb-6 inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-ocean-700"
          >
            <Sparkles size={14} className="text-soleil-500" />
            Association de jeunesse du Morbihan
          </motion.span>

          <motion.h1
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="text-5xl font-bold leading-[1.05] text-ocean-900 sm:text-6xl lg:text-7xl"
          >
            PILOXY <span className="bg-gradient-maree bg-clip-text text-transparent">56</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="mt-6 max-w-lg text-lg text-ocean-700"
          >
            Des jeunes, des idées, une énergie. Rejoignez une communauté qui organise
            événements, sorties et actions citoyennes partout dans le Morbihan.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.3 }}
            className="mt-10 flex flex-wrap gap-4"
          >
            <Link href="/association" className="btn-primary">
              Découvrir <ArrowRight size={18} />
            </Link>
            <Link href="/devenir-adherent" className="btn-secondary">
              Nous rejoindre
            </Link>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, scale: 0.92 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="relative hidden aspect-square items-center justify-center lg:flex"
        >
          <div className="glass-card-dark absolute inset-8 flex items-center justify-center overflow-hidden">
            <div className="animate-float text-center text-white">
              <p className="font-display text-6xl font-bold">56</p>
              <p className="mt-2 text-sm uppercase tracking-[0.3em] text-algue-200">Morbihan</p>
            </div>
          </div>
          <div className="absolute -bottom-6 -left-6 h-28 w-28 rounded-3xl bg-soleil-400 shadow-glass" />
          <div className="absolute -right-4 -top-4 h-20 w-20 rounded-full bg-algue-400 shadow-glass" />
        </motion.div>
      </div>
    </section>
  );
}
