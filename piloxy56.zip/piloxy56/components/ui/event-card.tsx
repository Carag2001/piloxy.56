import Link from "next/link";
import { CalendarDays, MapPin, Users } from "lucide-react";

export interface EventCardData {
  id: string;
  slug: string;
  title: string;
  location: string;
  startsAt: string | Date;
  capacity: number | null;
  _count?: { participants: number };
  coverImageUrl?: string | null;
}

function formatDate(date: string | Date) {
  return new Intl.DateTimeFormat("fr-FR", {
    day: "numeric",
    month: "long",
    hour: "2-digit",
    minute: "2-digit",
  }).format(new Date(date));
}

export function EventCard({ event }: { event: EventCardData }) {
  const registered = event._count?.participants ?? 0;
  const full = event.capacity !== null && registered >= (event.capacity ?? 0);

  return (
    <Link
      href={`/evenements/${event.slug}`}
      className="glass-card group flex flex-col overflow-hidden transition-all duration-300 hover:-translate-y-1 hover:shadow-glass-lg"
    >
      <div className="relative h-44 w-full overflow-hidden bg-gradient-maree">
        {event.coverImageUrl && (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={event.coverImageUrl}
            alt={event.title}
            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
        )}
        {full && (
          <span className="absolute right-3 top-3 rounded-full bg-ocean-900/80 px-3 py-1 text-xs font-semibold text-white">
            Complet
          </span>
        )}
      </div>
      <div className="flex flex-1 flex-col gap-3 p-6">
        <h3 className="font-display text-lg font-bold text-ocean-900 group-hover:text-algue-600">
          {event.title}
        </h3>
        <div className="mt-auto space-y-2 text-sm text-ocean-600">
          <p className="flex items-center gap-2">
            <CalendarDays size={16} /> {formatDate(event.startsAt)}
          </p>
          <p className="flex items-center gap-2">
            <MapPin size={16} /> {event.location}
          </p>
          {event.capacity && (
            <p className="flex items-center gap-2">
              <Users size={16} /> {registered}/{event.capacity} inscrits
            </p>
          )}
        </div>
      </div>
    </Link>
  );
}
