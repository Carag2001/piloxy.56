"use client";

import { useState } from "react";
import { signIn } from "next-auth/react";
import { useRouter } from "next/navigation";
import { Loader2 } from "lucide-react";

export function LoginForm() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    const res = await signIn("credentials", {
      email,
      password,
      redirect: false,
    });

    setLoading(false);

    if (res?.error) {
      setError("Email ou mot de passe incorrect.");
      return;
    }
    router.push("/dashboard");
    router.refresh();
  };

  return (
    <div className="space-y-5">
      <button
        onClick={() => signIn("google", { callbackUrl: "/dashboard" })}
        className="btn-secondary w-full"
        type="button"
      >
        Continuer avec Google
      </button>

      <div className="flex items-center gap-3 text-xs text-ocean-400">
        <span className="h-px flex-1 bg-ocean-200" /> ou <span className="h-px flex-1 bg-ocean-200" />
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="mb-1.5 block text-sm font-medium text-ocean-800">Email</label>
          <input
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full rounded-xl border border-ocean-200 bg-white/80 px-4 py-3 text-sm outline-none focus:border-algue-500"
          />
        </div>
        <div>
          <div className="mb-1.5 flex items-center justify-between">
            <label className="block text-sm font-medium text-ocean-800">Mot de passe</label>
            <a href="/mot-de-passe-oublie" className="text-xs text-algue-600 hover:underline">
              Oublié ?
            </a>
          </div>
          <input
            type="password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full rounded-xl border border-ocean-200 bg-white/80 px-4 py-3 text-sm outline-none focus:border-algue-500"
          />
        </div>

        {error && <p className="text-sm text-red-500">{error}</p>}

        <button type="submit" disabled={loading} className="btn-primary w-full">
          {loading ? <Loader2 className="animate-spin" size={18} /> : "Se connecter"}
        </button>
      </form>
    </div>
  );
}
