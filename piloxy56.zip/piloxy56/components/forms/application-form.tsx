"use client";

import { useState } from "react";
import { Loader2, CheckCircle2 } from "lucide-react";

interface ApplicationFormProps {
  type: "VOLUNTEER" | "MEMBER";
}

const initialState = {
  firstName: "",
  lastName: "",
  birthDate: "",
  address: "",
  phone: "",
  email: "",
  motivation: "",
  availability: "",
  skills: "",
  gdprAccepted: false,
};

export function ApplicationForm({ type }: ApplicationFormProps) {
  const [form, setForm] = useState(initialState);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/applications", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, type }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Une erreur est survenue");
      setSuccess(true);
      setForm(initialState);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Une erreur est survenue");
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="flex flex-col items-center gap-3 py-12 text-center">
        <CheckCircle2 className="text-algue-500" size={48} />
        <p className="font-display text-lg font-bold text-ocean-900">Candidature envoyée !</p>
        <p className="text-sm text-ocean-600">
          Merci, notre équipe reviendra vers vous rapidement.
        </p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Prénom" value={form.firstName} onChange={(v) => setForm({ ...form, firstName: v })} required />
        <Field label="Nom" value={form.lastName} onChange={(v) => setForm({ ...form, lastName: v })} required />
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Date de naissance" type="date" value={form.birthDate} onChange={(v) => setForm({ ...form, birthDate: v })} required />
        <Field label="Téléphone" value={form.phone} onChange={(v) => setForm({ ...form, phone: v })} required />
      </div>
      <Field label="Adresse" value={form.address} onChange={(v) => setForm({ ...form, address: v })} />
      <Field label="Email" type="email" value={form.email} onChange={(v) => setForm({ ...form, email: v })} required />
      {type === "VOLUNTEER" && (
        <>
          <Field label="Disponibilités" value={form.availability} onChange={(v) => setForm({ ...form, availability: v })} />
          <Field label="Compétences" value={form.skills} onChange={(v) => setForm({ ...form, skills: v })} />
        </>
      )}
      <div>
        <label className="mb-1.5 block text-sm font-medium text-ocean-800">Motivation</label>
        <textarea
          rows={4}
          value={form.motivation}
          onChange={(e) => setForm({ ...form, motivation: e.target.value })}
          className="w-full rounded-xl border border-ocean-200 bg-white/80 px-4 py-3 text-sm outline-none focus:border-algue-500"
        />
      </div>

      <label className="flex items-start gap-2 text-xs text-ocean-600">
        <input
          type="checkbox"
          required
          checked={form.gdprAccepted}
          onChange={(e) => setForm({ ...form, gdprAccepted: e.target.checked })}
          className="mt-0.5"
        />
        J&apos;accepte que mes données soient traitées conformément à la politique de confidentialité (RGPD).
      </label>

      {error && <p className="text-sm text-red-500">{error}</p>}

      <button type="submit" disabled={loading} className="btn-primary w-full">
        {loading ? <Loader2 className="animate-spin" size={18} /> : "Envoyer ma candidature"}
      </button>
    </form>
  );
}

function Field({
  label,
  value,
  onChange,
  type = "text",
  required = false,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
  required?: boolean;
}) {
  return (
    <div>
      <label className="mb-1.5 block text-sm font-medium text-ocean-800">{label}</label>
      <input
        type={type}
        required={required}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-xl border border-ocean-200 bg-white/80 px-4 py-3 text-sm outline-none focus:border-algue-500"
      />
    </div>
  );
}
