"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Loader2, CheckCircle2 } from "lucide-react";

const schema = z.object({
  name: z.string().min(2, "Nom trop court"),
  email: z.string().email("Email invalide"),
  subject: z.string().min(2, "Sujet requis"),
  message: z.string().min(10, "Message trop court (10 caractères minimum)"),
});

type FormValues = z.infer<typeof schema>;

export function ContactForm() {
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">("idle");
  const [errorMsg, setErrorMsg] = useState("");

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<FormValues>({ resolver: zodResolver(schema) });

  const onSubmit = async (data: FormValues) => {
    setStatus("loading");
    setErrorMsg("");
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error ?? "Une erreur est survenue");
      setStatus("success");
      reset();
    } catch (err) {
      setStatus("error");
      setErrorMsg(err instanceof Error ? err.message : "Une erreur est survenue");
    }
  };

  if (status === "success") {
    return (
      <div className="flex flex-col items-center gap-3 py-12 text-center">
        <CheckCircle2 className="text-algue-500" size={48} />
        <p className="font-display text-lg font-bold text-ocean-900">Message envoyé !</p>
        <p className="text-sm text-ocean-600">Nous vous répondrons dans les plus brefs délais.</p>
        <button className="btn-secondary mt-4" onClick={() => setStatus("idle")}>
          Envoyer un autre message
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
      <div>
        <label className="mb-1.5 block text-sm font-medium text-ocean-800">Nom complet</label>
        <input
          {...register("name")}
          className="w-full rounded-xl border border-ocean-200 bg-white/80 px-4 py-3 text-sm outline-none transition focus:border-algue-500"
          placeholder="Jeanne Dupont"
        />
        {errors.name && <p className="mt-1 text-xs text-red-500">{errors.name.message}</p>}
      </div>

      <div>
        <label className="mb-1.5 block text-sm font-medium text-ocean-800">Email</label>
        <input
          {...register("email")}
          type="email"
          className="w-full rounded-xl border border-ocean-200 bg-white/80 px-4 py-3 text-sm outline-none transition focus:border-algue-500"
          placeholder="jeanne@exemple.fr"
        />
        {errors.email && <p className="mt-1 text-xs text-red-500">{errors.email.message}</p>}
      </div>

      <div>
        <label className="mb-1.5 block text-sm font-medium text-ocean-800">Sujet</label>
        <input
          {...register("subject")}
          className="w-full rounded-xl border border-ocean-200 bg-white/80 px-4 py-3 text-sm outline-none transition focus:border-algue-500"
          placeholder="Partenariat, question, idée..."
        />
        {errors.subject && <p className="mt-1 text-xs text-red-500">{errors.subject.message}</p>}
      </div>

      <div>
        <label className="mb-1.5 block text-sm font-medium text-ocean-800">Message</label>
        <textarea
          {...register("message")}
          rows={5}
          className="w-full rounded-xl border border-ocean-200 bg-white/80 px-4 py-3 text-sm outline-none transition focus:border-algue-500"
          placeholder="Votre message..."
        />
        {errors.message && <p className="mt-1 text-xs text-red-500">{errors.message.message}</p>}
      </div>

      {status === "error" && <p className="text-sm text-red-500">{errorMsg}</p>}

      <button type="submit" disabled={status === "loading"} className="btn-primary w-full">
        {status === "loading" ? <Loader2 className="animate-spin" size={18} /> : "Envoyer le message"}
      </button>
    </form>
  );
}
