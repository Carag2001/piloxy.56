"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Loader2, CheckCircle2 } from "lucide-react";

export function RegisterForm() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);
  const [form, setForm] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    birthDate: "",
    phone: "",
    gdprAccepted: false,
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      const res = await fetch("/api/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Une erreur est survenue");
      setSuccess(true);
      setTimeout(() => router.push("/connexion"), 1800);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Une erreur est survenue");
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="flex flex-col items-center gap-3 py-8 text-center">
        <CheckCircle2 className="text-algue-500" size={48} />
        <p className="font-display text-lg font-bold text-ocean-900">Compte créé !</p>
        <p className="text-sm text-ocean-600">Redirection vers la connexion...</p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="mb-1.5 block text-sm font-medium text-ocean-800">Prénom</label>
          <input
            required
            value={form.firstName}
            onChange={(e) => setForm({ ...form, firstName: e.target.value })}
            className="w-full rounded-xl border border-ocean-200 bg-white/80 px-4 py-3 text-sm outline-none focus:border-algue-500"
          />
        </div>
        <div>
          <label className="mb-1.5 block text-sm font-medium text-ocean-800">Nom</label>
          <input
            required
            value={form.lastName}
            onChange={(e) => setForm({ ...form, lastName: e.target.value })}
            className="w-full rounded-xl border border-ocean-200 bg-white/80 px-4 py-3 text-sm outline-none focus:border-algue-500"
          />
        </div>
      </div>

      <div>
        <label className="mb-1.5 block text-sm font-medium text-ocean-800">Date de naissance</label>
        <input
          type="date"
          required
          value={form.birthDate}
          onChange={(e) => setForm({ ...form, birthDate: e.target.value })}
          className="w-full rounded-xl border border-ocean-200 bg-white/80 px-4 py-3 text-sm outline-none focus:border-algue-500"
        />
      </div>

      <div>
        <label className="mb-1.5 block text-sm font-medium text-ocean-800">Téléphone</label>
        <input
          value={form.phone}
          onChange={(e) => setForm({ ...form, phone: e.target.value })}
          className="w-full rounded-xl border border-ocean-200 bg-white/80 px-4 py-3 text-sm outline-none focus:border-algue-500"
        />
      </div>

      <div>
        <label className="mb-1.5 block text-sm font-medium text-ocean-800">Email</label>
        <input
          type="email"
          required
          value={form.email}
          onChange={(e) => setForm({ ...form, email: e.target.value })}
          className="w-full rounded-xl border border-ocean-200 bg-white/80 px-4 py-3 text-sm outline-none focus:border-algue-500"
        />
      </div>

      <div>
        <label className="mb-1.5 block text-sm font-medium text-ocean-800">Mot de passe</label>
        <input
          type="password"
          required
          minLength={8}
          value={form.password}
          onChange={(e) => setForm({ ...form, password: e.target.value })}
          className="w-full rounded-xl border border-ocean-200 bg-white/80 px-4 py-3 text-sm outline-none focus:border-algue-500"
        />
        <p className="mt-1 text-xs text-ocean-400">8 caractères minimum.</p>
      </div>

      <label className="flex items-start gap-2 text-xs text-ocean-600">
        <input
          type="checkbox"
          required
          checked={form.gdprAccepted}
          onChange={(e) => setForm({ ...form, gdprAccepted: e.target.checked })}
          className="mt-0.5"
        />
        J&apos;accepte la politique de confidentialité et le règlement intérieur de PILOXY 56.
      </label>

      {error && <p className="text-sm text-red-500">{error}</p>}

      <button type="submit" disabled={loading} className="btn-primary w-full">
        {loading ? <Loader2 className="animate-spin" size={18} /> : "Créer mon compte"}
      </button>
    </form>
  );
}
