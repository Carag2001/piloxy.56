"use client";

import { useState } from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { Loader2, CheckCircle2 } from "lucide-react";

export function EventRegisterButton({ eventId, full }: { eventId: string; full: boolean }) {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState("");

  if (status === "loading") return null;

  if (!session) {
    return (
      <button onClick={() => router.push("/connexion")} className="btn-primary w-full">
        Se connecter pour participer
      </button>
    );
  }

  const handleRegister = async () => {
    setLoading(true);
    setError("");
    try {
      const res = await fetch(`/api/events/${eventId}/register`, { method: "POST" });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Une erreur est survenue");
      setDone(true);
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Une erreur est survenue");
    } finally {
      setLoading(false);
    }
  };

  if (done) {
    return (
      <div className="glass-card flex items-center justify-center gap-2 p-4 text-algue-700">
        <CheckCircle2 size={20} /> Inscription confirmée
      </div>
    );
  }

  return (
    <div>
      <button onClick={handleRegister} disabled={loading} className="btn-primary w-full">
        {loading ? (
          <Loader2 className="animate-spin" size={18} />
        ) : full ? (
          "Rejoindre la liste d'attente"
        ) : (
          "Participer à l'événement"
        )}
      </button>
      {error && <p className="mt-2 text-center text-sm text-red-500">{error}</p>}
    </div>
  );
}
