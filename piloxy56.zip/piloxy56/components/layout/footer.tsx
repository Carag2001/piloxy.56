import Link from "next/link";
import { Waves, Instagram, Facebook, Mail, Phone, MapPin } from "lucide-react";

export function Footer() {
  return (
    <footer className="relative overflow-hidden bg-ocean-900 text-white">
      <div className="container-page grid gap-12 py-16 md:grid-cols-4">
        <div>
          <div className="mb-4 flex items-center gap-2">
            <span className="flex h-10 w-10 items-center justify-center rounded-2xl bg-gradient-maree">
              <Waves size={20} />
            </span>
            <span className="font-display text-lg font-bold">PILOXY 56</span>
          </div>
          <p className="text-sm text-ocean-200">Des jeunes, des idées, une énergie.</p>
          <div className="mt-6 flex gap-3">
            <a href="#" aria-label="Instagram" className="rounded-full bg-white/10 p-2 hover:bg-white/20">
              <Instagram size={16} />
            </a>
            <a href="#" aria-label="Facebook" className="rounded-full bg-white/10 p-2 hover:bg-white/20">
              <Facebook size={16} />
            </a>
          </div>
        </div>

        <div>
          <h3 className="mb-4 text-sm font-semibold uppercase tracking-wide text-algue-300">Navigation</h3>
          <ul className="space-y-2 text-sm text-ocean-200">
            <li><Link href="/association" className="hover:text-white">L&apos;association</Link></li>
            <li><Link href="/evenements" className="hover:text-white">Événements</Link></li>
            <li><Link href="/actualites" className="hover:text-white">Actualités</Link></li>
            <li><Link href="/devenir-benevole" className="hover:text-white">Devenir bénévole</Link></li>
            <li><Link href="/devenir-adherent" className="hover:text-white">Devenir adhérent</Link></li>
          </ul>
        </div>

        <div>
          <h3 className="mb-4 text-sm font-semibold uppercase tracking-wide text-algue-300">Contact</h3>
          <ul className="space-y-3 text-sm text-ocean-200">
            <li className="flex items-center gap-2"><MapPin size={16} /> Morbihan (56), Bretagne</li>
            <li className="flex items-center gap-2"><Phone size={16} /> 02 XX XX XX XX</li>
            <li className="flex items-center gap-2"><Mail size={16} /> contact@piloxy56.fr</li>
          </ul>
        </div>

        <div>
          <h3 className="mb-4 text-sm font-semibold uppercase tracking-wide text-algue-300">Légal</h3>
          <ul className="space-y-2 text-sm text-ocean-200">
            <li><Link href="/mentions-legales" className="hover:text-white">Mentions légales</Link></li>
            <li><Link href="/confidentialite" className="hover:text-white">Politique de confidentialité</Link></li>
            <li><Link href="/cgu" className="hover:text-white">CGU</Link></li>
            <li><Link href="/cookies" className="hover:text-white">Cookies</Link></li>
          </ul>
        </div>
      </div>

      <div className="border-t border-white/10 py-6 text-center text-xs text-ocean-300">
        © {new Date().getFullYear()} PILOXY 56 — Tous droits réservés.
      </div>
    </footer>
  );
}
