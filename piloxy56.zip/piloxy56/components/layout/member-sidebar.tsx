"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { signOut } from "next-auth/react";
import {
  Home,
  User,
  CalendarDays,
  FolderOpen,
  Images,
  Megaphone,
  Settings,
  LogOut,
  ChevronLeft,
  Waves,
} from "lucide-react";

const LINKS = [
  { href: "/dashboard", label: "Accueil", icon: Home },
  { href: "/dashboard/profil", label: "Mon profil", icon: User },
  { href: "/dashboard/evenements", label: "Mes événements", icon: CalendarDays },
  { href: "/dashboard/documents", label: "Mes documents", icon: FolderOpen },
  { href: "/dashboard/galerie", label: "Galerie privée", icon: Images },
  { href: "/dashboard/annonces", label: "Annonces", icon: Megaphone },
  { href: "/dashboard/parametres", label: "Paramètres", icon: Settings },
];

export function MemberSidebar() {
  const [collapsed, setCollapsed] = useState(false);
  const pathname = usePathname();

  return (
    <aside
      className={`sticky top-0 flex h-screen flex-col border-r border-white/40 bg-white/60 backdrop-blur-xl transition-all duration-300 ${
        collapsed ? "w-20" : "w-72"
      }`}
    >
      <div className="flex items-center justify-between p-5">
        <Link href="/" className="flex items-center gap-2 overflow-hidden">
          <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-gradient-maree text-white">
            <Waves size={18} />
          </span>
          {!collapsed && <span className="font-display font-bold text-ocean-900">PILOXY 56</span>}
        </Link>
        <button
          onClick={() => setCollapsed((c) => !c)}
          className="rounded-lg p-1.5 text-ocean-500 hover:bg-white"
          aria-label="Réduire le menu"
        >
          <ChevronLeft className={`transition-transform ${collapsed ? "rotate-180" : ""}`} size={18} />
        </button>
      </div>

      <nav className="flex-1 space-y-1 px-3">
        {LINKS.map((link) => {
          const active = pathname === link.href;
          return (
            <Link
              key={link.href}
              href={link.href}
              className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors ${
                active
                  ? "bg-gradient-maree text-white shadow-glass"
                  : "text-ocean-700 hover:bg-white"
              }`}
            >
              <link.icon size={18} className="shrink-0" />
              {!collapsed && <span>{link.label}</span>}
            </Link>
          );
        })}
      </nav>

      <button
        onClick={() => signOut({ callbackUrl: "/" })}
        className="m-3 flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-red-500 hover:bg-red-50"
      >
        <LogOut size={18} />
        {!collapsed && <span>Déconnexion</span>}
      </button>
    </aside>
  );
}
