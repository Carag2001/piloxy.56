"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X, Waves } from "lucide-react";
import { useSession } from "next-auth/react";

const NAV_LINKS = [
  { href: "/", label: "Accueil" },
  { href: "/association", label: "L'association" },
  { href: "/evenements", label: "Événements" },
  { href: "/actualites", label: "Actualités" },
  { href: "/contact", label: "Contact" },
];

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const { data: session } = useSession();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${
        scrolled
          ? "bg-white/70 backdrop-blur-xl shadow-glass border-b border-white/40"
          : "bg-transparent"
      }`}
    >
      <div className="container-page flex h-20 items-center justify-between">
        <Link href="/" className="flex items-center gap-2 group">
          <span className="flex h-10 w-10 items-center justify-center rounded-2xl bg-gradient-maree text-white shadow-glass transition-transform group-hover:scale-105">
            <Waves size={20} strokeWidth={2.5} />
          </span>
          <div className="leading-tight">
            <p className="font-display text-lg font-bold text-ocean-900">PILOXY 56</p>
            <p className="hidden text-[11px] font-medium text-ocean-600 sm:block">
              Des jeunes, des idées, une énergie.
            </p>
          </div>
        </Link>

        <nav className="hidden items-center gap-8 lg:flex">
          {NAV_LINKS.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="text-sm font-medium text-ocean-800 transition-colors hover:text-algue-600"
            >
              {link.label}
            </Link>
          ))}
        </nav>

        <div className="hidden items-center gap-3 lg:flex">
          {session ? (
            <Link href="/dashboard" className="btn-primary !py-2.5 !px-5 text-sm">
              Mon espace
            </Link>
          ) : (
            <>
              <Link href="/connexion" className="text-sm font-semibold text-ocean-800 hover:text-algue-600">
                Connexion
              </Link>
              <Link href="/devenir-adherent" className="btn-primary !py-2.5 !px-5 text-sm">
                Nous rejoindre
              </Link>
            </>
          )}
        </div>

        <button
          className="rounded-xl p-2 text-ocean-800 lg:hidden"
          onClick={() => setOpen((o) => !o)}
          aria-label={open ? "Fermer le menu" : "Ouvrir le menu"}
        >
          {open ? <X /> : <Menu />}
        </button>
      </div>

      <AnimatePresence>
        {open && (
          <motion.nav
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden bg-white/95 backdrop-blur-xl lg:hidden"
          >
            <div className="container-page flex flex-col gap-1 pb-6">
              {NAV_LINKS.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  onClick={() => setOpen(false)}
                  className="rounded-xl px-4 py-3 text-sm font-medium text-ocean-800 hover:bg-sable-200"
                >
                  {link.label}
                </Link>
              ))}
              <div className="mt-2 flex flex-col gap-2 px-4">
                <Link href="/connexion" onClick={() => setOpen(false)} className="btn-secondary w-full">
                  Connexion
                </Link>
                <Link href="/devenir-adherent" onClick={() => setOpen(false)} className="btn-primary w-full">
                  Nous rejoindre
                </Link>
              </div>
            </div>
          </motion.nav>
        )}
      </AnimatePresence>
    </header>
  );
}
