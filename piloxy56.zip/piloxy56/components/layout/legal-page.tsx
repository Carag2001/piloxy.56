export function LegalPage({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="container-page pt-32 pb-24">
      <h1 className="text-4xl font-bold text-ocean-900">{title}</h1>
      <div className="glass-card prose prose-sm mt-10 max-w-3xl p-8 text-ocean-700">{children}</div>
    </div>
  );
}
