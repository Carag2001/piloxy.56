import { withAuth } from "next-auth/middleware";

// Protège toutes les routes de l'espace membre : redirige vers /connexion
// si l'utilisateur n'est pas authentifié.
export default withAuth({
  pages: {
    signIn: "/connexion",
  },
});

export const config = {
  matcher: ["/dashboard/:path*", "/admin/:path*"],
};
