import Link from "next/link";
import { RegisterForm } from "@/components/forms/register-form";

export default function RegisterPage() {
  return (
    <div>
      <h1 className="text-center font-display text-2xl font-bold text-ocean-900">Créer un compte</h1>
      <p className="mt-2 text-center text-sm text-ocean-600">
        Rejoignez la communauté PILOXY 56.
      </p>
      <div className="mt-8">
        <RegisterForm />
      </div>
      <p className="mt-6 text-center text-sm text-ocean-600">
        Déjà un compte ?{" "}
        <Link href="/connexion" className="font-semibold text-algue-600 hover:underline">
          Se connecter
        </Link>
      </p>
    </div>
  );
}
