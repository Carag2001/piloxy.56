import Link from "next/link";
import { Waves } from "lucide-react";

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-aube px-4 py-12">
      <div className="w-full max-w-md">
        <Link href="/" className="mb-8 flex items-center justify-center gap-2">
          <span className="flex h-10 w-10 items-center justify-center rounded-2xl bg-gradient-maree text-white">
            <Waves size={20} />
          </span>
          <span className="font-display text-lg font-bold text-ocean-900">PILOXY 56</span>
        </Link>
        <div className="glass-card p-8">{children}</div>
      </div>
    </div>
  );
}
