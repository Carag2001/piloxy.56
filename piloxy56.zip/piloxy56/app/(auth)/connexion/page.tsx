import Link from "next/link";
import { LoginForm } from "@/components/forms/login-form";

export default function LoginPage() {
  return (
    <div>
      <h1 className="text-center font-display text-2xl font-bold text-ocean-900">Connexion</h1>
      <p className="mt-2 text-center text-sm text-ocean-600">
        Accédez à votre espace membre PILOXY 56.
      </p>
      <div className="mt-8">
        <LoginForm />
      </div>
      <p className="mt-6 text-center text-sm text-ocean-600">
        Pas encore de compte ?{" "}
        <Link href="/inscription" className="font-semibold text-algue-600 hover:underline">
          Créer un compte
        </Link>
      </p>
    </div>
  );
}
