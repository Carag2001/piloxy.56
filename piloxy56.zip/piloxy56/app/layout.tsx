import type { Metadata, Viewport } from "next";
import { Space_Grotesk, Inter } from "next/font/google";
import { Providers } from "@/components/providers";
import "./globals.css";

const display = Space_Grotesk({
  subsets: ["latin"],
  variable: "--font-display",
  weight: ["500", "600", "700"],
});

const body = Inter({
  subsets: ["latin"],
  variable: "--font-body",
});

export const metadata: Metadata = {
  metadataBase: new URL("https://piloxy56.fr"),
  title: {
    default: "PILOXY 56 — Des jeunes, des idées, une énergie.",
    template: "%s | PILOXY 56",
  },
  description:
    "PILOXY 56 est une association de jeunesse du Morbihan qui organise événements, sorties et actions citoyennes. Rejoignez une communauté pleine d'énergie.",
  keywords: ["association", "jeunesse", "Morbihan", "56", "bénévolat", "événements", "Bretagne"],
  openGraph: {
    title: "PILOXY 56 — Des jeunes, des idées, une énergie.",
    description: "Association de jeunesse du Morbihan. Événements, bénévolat, actions citoyennes.",
    url: "https://piloxy56.fr",
    siteName: "PILOXY 56",
    locale: "fr_FR",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "PILOXY 56",
    description: "Des jeunes, des idées, une énergie.",
  },
  robots: { index: true, follow: true },
  manifest: "/manifest.json",
};

export const viewport: Viewport = {
  themeColor: "#0C7C92",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr" className={`${display.variable} ${body.variable}`} suppressHydrationWarning>
      <body>
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
