import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";

const applicationSchema = z.object({
  type: z.enum(["VOLUNTEER", "MEMBER"]),
  firstName: z.string().min(2),
  lastName: z.string().min(2),
  birthDate: z.string(),
  address: z.string().optional(),
  phone: z.string().min(6),
  email: z.string().email(),
  motivation: z.string().optional(),
  availability: z.string().optional(),
  skills: z.string().optional(),
  gdprAccepted: z.boolean().refine((v) => v === true, "Acceptation RGPD requise"),
});

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const data = applicationSchema.parse(body);

    const application = await prisma.application.create({
      data: { ...data, birthDate: new Date(data.birthDate) },
    });

    return NextResponse.json(
      { message: "Candidature envoyée avec succès.", id: application.id },
      { status: 201 }
    );
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: error.errors[0].message }, { status: 400 });
    }
    console.error("[APPLICATION_ERROR]", error);
    return NextResponse.json({ error: "Une erreur est survenue." }, { status: 500 });
  }
}
