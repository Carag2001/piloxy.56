import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

/**
 * Liste les événements publiés.
 * Query params optionnels :
 *  - upcoming=true  → uniquement les événements à venir
 *  - limit=6        → limite le nombre de résultats
 */
export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const upcomingOnly = searchParams.get("upcoming") === "true";
  const limit = Number(searchParams.get("limit")) || 20;

  const events = await prisma.event.findMany({
    where: {
      status: "PUBLISHED",
      deletedAt: null,
      ...(upcomingOnly ? { startsAt: { gte: new Date() } } : {}),
    },
    include: {
      activity: true,
      _count: { select: { participants: true } },
    },
    orderBy: { startsAt: upcomingOnly ? "asc" : "desc" },
    take: limit,
  });

  return NextResponse.json({ events });
}
