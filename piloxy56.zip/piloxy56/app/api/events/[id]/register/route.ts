import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

interface Params {
  params: { id: string };
}

// Inscription à un événement
export async function POST(request: NextRequest, { params }: Params) {
  const session = await getServerSession(authOptions);
  if (!session) {
    return NextResponse.json({ error: "Vous devez être connecté." }, { status: 401 });
  }

  const event = await prisma.event.findUnique({
    where: { id: params.id },
    include: { _count: { select: { participants: true } } },
  });
  if (!event || event.status !== "PUBLISHED") {
    return NextResponse.json({ error: "Événement introuvable." }, { status: 404 });
  }

  const alreadyRegistered = await prisma.eventParticipant.findUnique({
    where: { eventId_userId: { eventId: event.id, userId: session.user.id } },
  });
  if (alreadyRegistered) {
    return NextResponse.json({ error: "Vous êtes déjà inscrit(e)." }, { status: 409 });
  }

  const isFull = event.capacity !== null && event._count.participants >= event.capacity;

  const participant = await prisma.eventParticipant.create({
    data: {
      eventId: event.id,
      userId: session.user.id,
      status: isFull ? "WAITLISTED" : "REGISTERED",
    },
  });

  await prisma.activityLog.create({
    data: { userId: session.user.id, action: "CREATE", module: "events", targetId: event.id },
  });

  return NextResponse.json({ participant }, { status: 201 });
}

// Désinscription
export async function DELETE(_request: NextRequest, { params }: Params) {
  const session = await getServerSession(authOptions);
  if (!session) {
    return NextResponse.json({ error: "Vous devez être connecté." }, { status: 401 });
  }

  await prisma.eventParticipant.updateMany({
    where: { eventId: params.id, userId: session.user.id },
    data: { status: "CANCELLED" },
  });

  return NextResponse.json({ message: "Inscription annulée." });
}
