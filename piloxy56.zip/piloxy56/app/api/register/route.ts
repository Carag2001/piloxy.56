import { NextRequest, NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { prisma } from "@/lib/prisma";

// Validation stricte des données d'inscription.
const registerSchema = z.object({
  firstName: z.string().min(2, "Prénom trop court"),
  lastName: z.string().min(2, "Nom trop court"),
  email: z.string().email("Email invalide"),
  password: z.string().min(8, "Le mot de passe doit contenir au moins 8 caractères"),
  birthDate: z.string().optional(),
  phone: z.string().optional(),
  gdprAccepted: z.boolean().refine((v) => v === true, "Acceptation RGPD requise"),
});

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const data = registerSchema.parse(body);

    const existing = await prisma.user.findUnique({ where: { email: data.email.toLowerCase() } });
    if (existing) {
      return NextResponse.json(
        { error: "Un compte existe déjà avec cet email." },
        { status: 409 }
      );
    }

    const defaultRole = await prisma.role.findUnique({ where: { slug: "adherent" } });
    if (!defaultRole) {
      return NextResponse.json(
        { error: "Configuration du site incomplète (rôle par défaut manquant)." },
        { status: 500 }
      );
    }

    const passwordHash = await bcrypt.hash(data.password, 12);
    const birthDate = data.birthDate ? new Date(data.birthDate) : null;

    // Détection automatique des mineurs : dossier d'autorisation à créer.
    const isMinor =
      birthDate !== null &&
      new Date().getFullYear() - birthDate.getFullYear() < 18;

    const user = await prisma.user.create({
      data: {
        firstName: data.firstName,
        lastName: data.lastName,
        email: data.email.toLowerCase(),
        passwordHash,
        phone: data.phone,
        birthDate,
        status: "PENDING",
        roleId: defaultRole.id,
      },
    });

    if (isMinor) {
      await prisma.minor.create({
        data: {
          userId: user.id,
          parentalAuthorization: false,
        },
      });
    }

    await prisma.activityLog.create({
      data: {
        userId: user.id,
        action: "CREATE",
        module: "users",
        targetId: user.id,
      },
    });

    return NextResponse.json(
      { message: "Compte créé avec succès. Vous pouvez maintenant vous connecter." },
      { status: 201 }
    );
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: error.errors[0].message }, { status: 400 });
    }
    console.error("[REGISTER_ERROR]", error);
    return NextResponse.json({ error: "Une erreur est survenue." }, { status: 500 });
  }
}
