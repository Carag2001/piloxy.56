import { prisma } from "@/lib/prisma";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { CalendarDays, MapPin, Users, Clock } from "lucide-react";
import { EventRegisterButton } from "@/components/forms/event-register-button";

interface Props {
  params: { slug: string };
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const event = await prisma.event.findUnique({ where: { slug: params.slug } });
  if (!event) return {};
  return {
    title: event.title,
    description: event.description.slice(0, 155),
    openGraph: { images: event.coverImageUrl ? [event.coverImageUrl] : [] },
  };
}

export default async function EventDetailPage({ params }: Props) {
  const event = await prisma.event.findUnique({
    where: { slug: params.slug },
    include: {
      activity: true,
      _count: { select: { participants: true } },
    },
  });

  if (!event || event.status !== "PUBLISHED") notFound();

  const dateFormatter = new Intl.DateTimeFormat("fr-FR", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });
  const timeFormatter = new Intl.DateTimeFormat("fr-FR", { hour: "2-digit", minute: "2-digit" });
  const registered = event._count.participants;
  const full = event.capacity !== null && registered >= event.capacity;

  return (
    <div className="pt-32 pb-24">
      <div className="relative h-72 w-full overflow-hidden bg-gradient-maree sm:h-96">
        {event.coverImageUrl && (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={event.coverImageUrl} alt={event.title} className="h-full w-full object-cover" />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-ocean-900/60 to-transparent" />
      </div>

      <div className="container-page -mt-20 relative grid gap-8 lg:grid-cols-3">
        <div className="glass-card lg:col-span-2 p-8">
          {event.activity && (
            <span className="mb-4 inline-block rounded-full bg-algue-100 px-3 py-1 text-xs font-semibold text-algue-700">
              {event.activity.name}
            </span>
          )}
          <h1 className="text-3xl font-bold text-ocean-900 sm:text-4xl">{event.title}</h1>
          <p className="mt-6 whitespace-pre-line text-ocean-700">{event.description}</p>

          {event.minAge && (
            <p className="mt-6 text-sm text-ocean-500">
              Âge minimum requis : <strong>{event.minAge} ans</strong>
            </p>
          )}
        </div>

        <div className="space-y-6">
          <div className="glass-card space-y-4 p-6">
            <div className="flex items-center gap-3 text-sm text-ocean-700">
              <CalendarDays size={18} className="text-algue-600" />
              <span className="capitalize">{dateFormatter.format(event.startsAt)}</span>
            </div>
            <div className="flex items-center gap-3 text-sm text-ocean-700">
              <Clock size={18} className="text-algue-600" />
              <span>
                {timeFormatter.format(event.startsAt)}
                {event.endsAt && ` — ${timeFormatter.format(event.endsAt)}`}
              </span>
            </div>
            <div className="flex items-center gap-3 text-sm text-ocean-700">
              <MapPin size={18} className="text-algue-600" />
              <span>{event.location}</span>
            </div>
            {event.capacity && (
              <div className="flex items-center gap-3 text-sm text-ocean-700">
                <Users size={18} className="text-algue-600" />
                <span>{registered}/{event.capacity} inscrits</span>
              </div>
            )}
          </div>

          <EventRegisterButton eventId={event.id} full={full} />
        </div>
      </div>
    </div>
  );
}
