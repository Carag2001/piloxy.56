import { prisma } from "@/lib/prisma";
import { EventCard } from "@/components/ui/event-card";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Événements",
  description: "Découvrez tous les événements organisés par PILOXY 56 dans le Morbihan.",
};

export const revalidate = 60;

export default async function EventsPage() {
  const events = await prisma.event.findMany({
    where: { status: "PUBLISHED", deletedAt: null },
    orderBy: { startsAt: "asc" },
    include: { _count: { select: { participants: true } } },
  });

  const upcoming = events.filter((e) => e.startsAt >= new Date());
  const past = events.filter((e) => e.startsAt < new Date());

  return (
    <div className="container-page pt-32 pb-24">
      <div className="text-center">
        <span className="section-eyebrow">Agenda</span>
        <h1 className="mt-3 text-4xl font-bold text-ocean-900 sm:text-5xl">Tous nos événements</h1>
        <p className="mx-auto mt-4 max-w-xl text-ocean-600">
          Barbecues, sorties, soirées, actions citoyennes... Il y en a pour tous les goûts.
        </p>
      </div>

      <section className="mt-16">
        <h2 className="mb-6 text-xl font-bold text-ocean-900">À venir</h2>
        {upcoming.length > 0 ? (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {upcoming.map((event) => (
              <EventCard key={event.id} event={event} />
            ))}
          </div>
        ) : (
          <div className="glass-card p-10 text-center text-ocean-600">
            Aucun événement à venir pour le moment.
          </div>
        )}
      </section>

      {past.length > 0 && (
        <section className="mt-16">
          <h2 className="mb-6 text-xl font-bold text-ocean-900">Événements passés</h2>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 opacity-70">
            {past.map((event) => (
              <EventCard key={event.id} event={event} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
