import { LegalPage } from "@/components/layout/legal-page";

export const metadata = { title: "Mentions légales" };

export default function MentionsLegalesPage() {
  return (
    <LegalPage title="Mentions légales">
      <p>
        Le site piloxy56.fr est édité par l&apos;association PILOXY 56, association loi 1901,
        dont le siège social est situé dans le Morbihan (56), Bretagne.
      </p>
      <p>
        <strong>À compléter par l&apos;association :</strong> numéro RNA, adresse complète du
        siège social, nom du représentant légal, coordonnées de l&apos;hébergeur du site.
      </p>
      <p>
        Directeur de la publication : le Président de l&apos;association PILOXY 56.
      </p>
    </LegalPage>
  );
}
