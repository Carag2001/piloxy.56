import { ContactForm } from "@/components/forms/contact-form";
import { Mail, Phone, MapPin } from "lucide-react";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Contact",
  description: "Contactez l'équipe PILOXY 56.",
};

export default function ContactPage() {
  return (
    <div className="container-page grid gap-12 pt-32 pb-24 lg:grid-cols-2">
      <div>
        <span className="section-eyebrow">Contact</span>
        <h1 className="mt-3 text-4xl font-bold text-ocean-900">Parlons de votre projet</h1>
        <p className="mt-4 text-ocean-600">
          Une question, une envie de partenariat, une idée d&apos;événement&nbsp;? Écrivez-nous.
        </p>

        <div className="mt-10 space-y-4">
          <div className="glass-card flex items-center gap-4 p-5">
            <span className="rounded-2xl bg-gradient-maree p-3 text-white"><MapPin size={18} /></span>
            <span className="text-ocean-700">Morbihan (56), Bretagne</span>
          </div>
          <div className="glass-card flex items-center gap-4 p-5">
            <span className="rounded-2xl bg-gradient-maree p-3 text-white"><Phone size={18} /></span>
            <span className="text-ocean-700">02 XX XX XX XX</span>
          </div>
          <div className="glass-card flex items-center gap-4 p-5">
            <span className="rounded-2xl bg-gradient-maree p-3 text-white"><Mail size={18} /></span>
            <span className="text-ocean-700">contact@piloxy56.fr</span>
          </div>
        </div>
      </div>

      <div className="glass-card p-8">
        <ContactForm />
      </div>
    </div>
  );
}
