import type { Metadata } from "next";
import { Compass, HeartHandshake, Users2, Target } from "lucide-react";

export const metadata: Metadata = {
  title: "L'association",
  description: "Découvrez l'histoire, les valeurs et les objectifs de PILOXY 56.",
};

const VALUES = [
  { icon: Compass, title: "Initiative", text: "Chaque jeune peut proposer et porter un projet." },
  { icon: HeartHandshake, title: "Solidarité", text: "L'entraide au cœur de chaque action menée." },
  { icon: Users2, title: "Communauté", text: "Un collectif ouvert à tous, partout dans le Morbihan." },
  { icon: Target, title: "Engagement", text: "Des actions concrètes, utiles et durables." },
];

export default function AssociationPage() {
  return (
    <div className="pt-32 pb-24">
      <div className="container-page text-center">
        <span className="section-eyebrow">Notre histoire</span>
        <h1 className="mt-3 text-4xl font-bold text-ocean-900 sm:text-5xl">L&apos;association PILOXY 56</h1>
        <p className="mx-auto mt-5 max-w-2xl text-ocean-600">
          Née de l&apos;envie d&apos;un groupe de jeunes du Morbihan de créer du lien et de
          s&apos;engager pour leur territoire, PILOXY 56 organise aujourd&apos;hui des
          événements toute l&apos;année, portés par des bénévoles passionnés.
        </p>
      </div>

      <div className="container-page mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {VALUES.map((v) => (
          <div key={v.title} className="glass-card p-6 text-center">
            <span className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-maree text-white">
              <v.icon size={20} />
            </span>
            <h3 className="font-display font-bold text-ocean-900">{v.title}</h3>
            <p className="mt-2 text-sm text-ocean-600">{v.text}</p>
          </div>
        ))}
      </div>

      <div className="container-page mt-20 grid gap-10 lg:grid-cols-2">
        <div className="glass-card p-8">
          <h2 className="font-display text-xl font-bold text-ocean-900">Nos objectifs</h2>
          <ul className="mt-4 space-y-3 text-sm text-ocean-600">
            <li>• Fédérer la jeunesse du Morbihan autour de projets communs</li>
            <li>• Organiser des événements accessibles à tous</li>
            <li>• Développer des actions citoyennes et solidaires</li>
            <li>• Accompagner les jeunes bénévoles dans leurs initiatives</li>
          </ul>
        </div>
        <div className="glass-card p-8">
          <h2 className="font-display text-xl font-bold text-ocean-900">Documents utiles</h2>
          <p className="mt-3 text-sm text-ocean-600">
            Statuts, règlement intérieur et rapports d&apos;activité sont disponibles sur
            demande auprès du bureau de l&apos;association.
          </p>
        </div>
      </div>
    </div>
  );
}
