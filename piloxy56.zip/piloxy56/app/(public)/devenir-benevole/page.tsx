import { ApplicationForm } from "@/components/forms/application-form";
import type { Metadata } from "next";

export const metadata: Metadata = { title: "Devenir bénévole" };

export default function BecomeVolunteerPage() {
  return (
    <div className="container-page pt-32 pb-24">
      <div className="mx-auto max-w-xl text-center">
        <span className="section-eyebrow">Bénévolat</span>
        <h1 className="mt-3 text-4xl font-bold text-ocean-900">Devenir bénévole</h1>
        <p className="mt-4 text-ocean-600">
          Donnez de votre temps et de votre énergie pour faire vivre nos événements.
        </p>
      </div>
      <div className="glass-card mx-auto mt-10 max-w-xl p-8">
        <ApplicationForm type="VOLUNTEER" />
      </div>
    </div>
  );
}
