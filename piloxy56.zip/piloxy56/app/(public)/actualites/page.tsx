import { prisma } from "@/lib/prisma";
import type { Metadata } from "next";
import Link from "next/link";
import { CalendarDays } from "lucide-react";

export const metadata: Metadata = { title: "Actualités" };
export const revalidate = 60;

export default async function NewsPage() {
  const news = await prisma.news.findMany({
    where: { status: "PUBLISHED" },
    orderBy: { publishedAt: "desc" },
    include: { author: { select: { firstName: true, lastName: true } } },
  });

  return (
    <div className="container-page pt-32 pb-24">
      <div className="text-center">
        <span className="section-eyebrow">Blog</span>
        <h1 className="mt-3 text-4xl font-bold text-ocean-900 sm:text-5xl">Actualités</h1>
      </div>

      {news.length > 0 ? (
        <div className="mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {news.map((item) => (
            <Link
              key={item.id}
              href={`/actualites/${item.slug}`}
              className="glass-card group flex flex-col overflow-hidden p-6 transition-all hover:-translate-y-1 hover:shadow-glass-lg"
            >
              {item.category && (
                <span className="mb-3 w-fit rounded-full bg-algue-100 px-3 py-1 text-xs font-semibold text-algue-700">
                  {item.category}
                </span>
              )}
              <h2 className="font-display text-lg font-bold text-ocean-900 group-hover:text-algue-600">
                {item.title}
              </h2>
              {item.excerpt && <p className="mt-2 text-sm text-ocean-600">{item.excerpt}</p>}
              <p className="mt-auto flex items-center gap-2 pt-4 text-xs text-ocean-400">
                <CalendarDays size={14} />
                {item.publishedAt &&
                  new Intl.DateTimeFormat("fr-FR", { day: "numeric", month: "long", year: "numeric" }).format(
                    item.publishedAt
                  )}
              </p>
            </Link>
          ))}
        </div>
      ) : (
        <div className="glass-card mt-16 p-12 text-center text-ocean-600">
          Aucune actualité publiée pour le moment.
        </div>
      )}
    </div>
  );
}
