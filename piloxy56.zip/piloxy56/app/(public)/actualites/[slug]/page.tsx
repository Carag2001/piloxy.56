import { prisma } from "@/lib/prisma";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { CalendarDays, User } from "lucide-react";

interface Props {
  params: { slug: string };
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const article = await prisma.news.findUnique({ where: { slug: params.slug } });
  if (!article) return {};
  return {
    title: article.title,
    description: article.excerpt ?? article.content.slice(0, 155),
  };
}

export default async function NewsDetailPage({ params }: Props) {
  const article = await prisma.news.findUnique({
    where: { slug: params.slug },
    include: { author: { select: { firstName: true, lastName: true } } },
  });

  if (!article || article.status !== "PUBLISHED") notFound();

  return (
    <article className="container-page max-w-3xl pt-32 pb-24">
      {article.category && (
        <span className="mb-4 inline-block rounded-full bg-algue-100 px-3 py-1 text-xs font-semibold text-algue-700">
          {article.category}
        </span>
      )}
      <h1 className="text-3xl font-bold text-ocean-900 sm:text-4xl">{article.title}</h1>
      <div className="mt-4 flex flex-wrap items-center gap-4 text-sm text-ocean-500">
        <span className="flex items-center gap-2">
          <User size={16} /> {article.author.firstName} {article.author.lastName}
        </span>
        {article.publishedAt && (
          <span className="flex items-center gap-2">
            <CalendarDays size={16} />
            {new Intl.DateTimeFormat("fr-FR", { day: "numeric", month: "long", year: "numeric" }).format(
              article.publishedAt
            )}
          </span>
        )}
      </div>

      {article.coverImageUrl && (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          src={article.coverImageUrl}
          alt={article.title}
          className="mt-8 w-full rounded-3xl object-cover shadow-glass"
        />
      )}

      <div className="prose prose-ocean mt-8 max-w-none whitespace-pre-line text-ocean-700">
        {article.content}
      </div>
    </article>
  );
}
