import { ApplicationForm } from "@/components/forms/application-form";
import type { Metadata } from "next";

export const metadata: Metadata = { title: "Devenir adhérent" };

export default function BecomeMemberPage() {
  return (
    <div className="container-page pt-32 pb-24">
      <div className="mx-auto max-w-xl text-center">
        <span className="section-eyebrow">Adhésion</span>
        <h1 className="mt-3 text-4xl font-bold text-ocean-900">Devenir adhérent</h1>
        <p className="mt-4 text-ocean-600">
          Rejoignez PILOXY 56 et participez à tous nos événements toute l&apos;année.
        </p>
      </div>
      <div className="glass-card mx-auto mt-10 max-w-xl p-8">
        <ApplicationForm type="MEMBER" />
      </div>
    </div>
  );
}
