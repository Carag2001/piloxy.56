import { LegalPage } from "@/components/layout/legal-page";

export const metadata = { title: "Politique de confidentialité" };

export default function ConfidentialitePage() {
  return (
    <LegalPage title="Politique de confidentialité">
      <p>
        PILOXY 56 accorde une attention particulière à la protection des données
        personnelles de ses membres, bénévoles, partenaires et visiteurs, conformément
        au Règlement Général sur la Protection des Données (RGPD).
      </p>
      <h3>Données collectées</h3>
      <p>
        Nom, prénom, email, téléphone, adresse, date de naissance (pour la gestion des
        mineurs), photo de profil, et données de connexion (adresse IP, appareil,
        navigateur) dans le cadre de la sécurisation des comptes.
      </p>
      <h3>Finalité</h3>
      <p>
        Ces données sont utilisées exclusivement pour la gestion des adhésions, des
        inscriptions aux événements, la communication interne et le respect des
        obligations légales liées à l&apos;encadrement de mineurs.
      </p>
      <h3>Vos droits</h3>
      <p>
        Conformément au RGPD, vous disposez d&apos;un droit d&apos;accès, de rectification,
        d&apos;effacement et de portabilité de vos données. Pour exercer ces droits,
        contactez-nous à contact@piloxy56.fr.
      </p>
      <h3>Conservation</h3>
      <p>
        Les données sont conservées pendant la durée d&apos;adhésion, augmentée des
        délais légaux de conservation applicables aux associations.
      </p>
    </LegalPage>
  );
}
