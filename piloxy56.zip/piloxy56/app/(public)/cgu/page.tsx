import { LegalPage } from "@/components/layout/legal-page";

export const metadata = { title: "Conditions générales d'utilisation" };

export default function CguPage() {
  return (
    <LegalPage title="Conditions générales d'utilisation">
      <h3>Objet</h3>
      <p>
        Les présentes CGU régissent l&apos;utilisation du site piloxy56.fr et de l&apos;espace
        membre associé, édités par l&apos;association PILOXY 56.
      </p>
      <h3>Accès au service</h3>
      <p>
        Le site public est accessible librement. L&apos;espace membre est réservé aux
        adhérents, bénévoles et personnes autorisées après création d&apos;un compte.
      </p>
      <h3>Comportement des utilisateurs</h3>
      <p>
        Chaque utilisateur s&apos;engage à fournir des informations exactes, à respecter le
        règlement intérieur de l&apos;association et à ne pas porter atteinte au bon
        fonctionnement du site.
      </p>
      <h3>Responsabilité</h3>
      <p>
        L&apos;association ne saurait être tenue responsable des interruptions de service
        indépendantes de sa volonté (maintenance, panne technique, cas de force majeure).
      </p>
    </LegalPage>
  );
}
