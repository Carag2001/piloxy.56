import { LegalPage } from "@/components/layout/legal-page";

export const metadata = { title: "Politique de cookies" };

export default function CookiesPage() {
  return (
    <LegalPage title="Politique de cookies">
      <p>
        Le site piloxy56.fr utilise des cookies strictement nécessaires à son
        fonctionnement, notamment pour la gestion de la session de connexion (cookie
        d&apos;authentification sécurisé, HttpOnly) et la mémorisation de vos préférences
        d&apos;affichage (thème clair/sombre).
      </p>
      <p>
        Aucun cookie publicitaire ou de traçage tiers n&apos;est utilisé sur ce site.
      </p>
    </LegalPage>
  );
}
