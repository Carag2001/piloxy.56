import { prisma } from "@/lib/prisma";
import { Hero } from "@/components/sections/hero";
import { Counter } from "@/components/ui/counter";
import { EventCard } from "@/components/ui/event-card";
import Link from "next/link";
import { ArrowRight, Compass, HeartHandshake, Users2 } from "lucide-react";

async function getHomeData() {
  const [upcomingEvents, memberCount, volunteerCount, eventCount] = await Promise.all([
    prisma.event.findMany({
      where: { status: "PUBLISHED", startsAt: { gte: new Date() }, deletedAt: null },
      orderBy: { startsAt: "asc" },
      take: 3,
      include: { _count: { select: { participants: true } } },
    }),
    prisma.user.count({ where: { deletedAt: null } }),
    prisma.role
      .findUnique({ where: { slug: "benevole" } })
      .then((r) => (r ? prisma.user.count({ where: { roleId: r.id } }) : 0)),
    prisma.event.count({ where: { status: { in: ["PUBLISHED", "ARCHIVED"] } } }),
  ]);

  return { upcomingEvents, memberCount, volunteerCount, eventCount };
}

const VALUES = [
  { icon: Compass, title: "Initiative", text: "Chaque idée compte : les jeunes sont acteurs de chaque projet." },
  { icon: HeartHandshake, title: "Solidarité", text: "Un esprit d'entraide entre bénévoles, adhérents et familles." },
  { icon: Users2, title: "Communauté", text: "Un réseau vivant à l'échelle du Morbihan et de ses communes." },
];

export default async function HomePage() {
  const { upcomingEvents, memberCount, volunteerCount, eventCount } = await getHomeData();

  return (
    <>
      <Hero />

      {/* CHIFFRES */}
      <section className="container-page -mt-16 relative z-10 grid grid-cols-2 gap-4 sm:grid-cols-4">
        <Counter value={memberCount} label="Membres" />
        <Counter value={volunteerCount} label="Bénévoles" />
        <Counter value={eventCount} label="Événements" />
        <Counter value={56} label="Le Morbihan" suffix="" />
      </section>

      {/* PRÉSENTATION */}
      <section className="container-page py-24">
        <div className="grid gap-12 lg:grid-cols-2 lg:items-center">
          <div>
            <span className="section-eyebrow">Qui sommes-nous</span>
            <h2 className="mt-3 text-3xl font-bold text-ocean-900 sm:text-4xl">
              Une association pensée par et pour la jeunesse du Morbihan
            </h2>
            <p className="mt-5 text-ocean-700">
              PILOXY 56 rassemble des jeunes qui veulent créer, partager et s&apos;engager.
              Barbecues, sorties, soirées, actions citoyennes : chaque événement est une
              occasion de tisser des liens et de faire vivre nos communes.
            </p>
            <Link href="/association" className="btn-primary mt-8">
              En savoir plus <ArrowRight size={18} />
            </Link>
          </div>
          <div className="grid gap-6 sm:grid-cols-3 lg:grid-cols-1">
            {VALUES.map((value) => (
              <div key={value.title} className="glass-card flex items-start gap-4 p-6">
                <span className="rounded-2xl bg-gradient-maree p-3 text-white">
                  <value.icon size={20} />
                </span>
                <div>
                  <h3 className="font-display font-bold text-ocean-900">{value.title}</h3>
                  <p className="mt-1 text-sm text-ocean-600">{value.text}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ÉVÉNEMENTS À VENIR */}
      <section className="bg-gradient-aube py-24">
        <div className="container-page">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <span className="section-eyebrow">Agenda</span>
              <h2 className="mt-3 text-3xl font-bold text-ocean-900 sm:text-4xl">
                Prochains événements
              </h2>
            </div>
            <Link href="/evenements" className="btn-secondary">
              Voir tout l&apos;agenda <ArrowRight size={16} />
            </Link>
          </div>

          {upcomingEvents.length > 0 ? (
            <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {upcomingEvents.map((event) => (
                <EventCard key={event.id} event={event} />
              ))}
            </div>
          ) : (
            <div className="glass-card mt-10 p-12 text-center text-ocean-600">
              Aucun événement programmé pour le moment. Revenez bientôt !
            </div>
          )}
        </div>
      </section>

      {/* CTA FINAL */}
      <section className="container-page py-24">
        <div className="glass-card-dark relative overflow-hidden px-8 py-16 text-center text-white sm:px-16">
          <div className="pointer-events-none absolute -left-20 -top-20 h-64 w-64 rounded-full bg-algue-500/30 blur-3xl" />
          <div className="pointer-events-none absolute -right-20 -bottom-20 h-64 w-64 rounded-full bg-soleil-400/20 blur-3xl" />
          <h2 className="relative text-3xl font-bold sm:text-4xl">Envie de nous rejoindre&nbsp;?</h2>
          <p className="relative mx-auto mt-4 max-w-xl text-ocean-100">
            Adhérent, bénévole ou partenaire : il y a une place pour vous chez PILOXY 56.
          </p>
          <div className="relative mt-8 flex flex-wrap justify-center gap-4">
            <Link href="/devenir-adherent" className="btn-primary">
              Devenir adhérent
            </Link>
            <Link href="/devenir-benevole" className="btn-secondary !bg-white/10 !text-white !border-white/30 hover:!bg-white/20">
              Devenir bénévole
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}
