import type { MetadataRoute } from "next";
import { prisma } from "@/lib/prisma";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const staticRoutes = [
    "", "association", "evenements", "actualites", "contact",
    "devenir-adherent", "devenir-benevole", "connexion", "inscription",
  ].map((route) => ({
    url: `https://piloxy56.fr/${route}`,
    lastModified: new Date(),
  }));

  const events = await prisma.event.findMany({
    where: { status: "PUBLISHED", deletedAt: null },
    select: { slug: true, updatedAt: true },
  });

  const eventRoutes = events.map((event) => ({
    url: `https://piloxy56.fr/evenements/${event.slug}`,
    lastModified: event.updatedAt,
  }));

  return [...staticRoutes, ...eventRoutes];
}
