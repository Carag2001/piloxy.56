import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { EventCard } from "@/components/ui/event-card";
import { CalendarDays, Bell, FileText } from "lucide-react";

export default async function DashboardPage() {
  const session = await getServerSession(authOptions);

  const user = await prisma.user.findUnique({
    where: { id: session!.user.id },
    include: { role: true },
  });

  const [upcomingEvents, notifications] = await Promise.all([
    prisma.event.findMany({
      where: { status: "PUBLISHED", startsAt: { gte: new Date() }, deletedAt: null },
      orderBy: { startsAt: "asc" },
      take: 3,
      include: { _count: { select: { participants: true } } },
    }),
    prisma.notification.findMany({
      where: { userId: session!.user.id, isRead: false },
      orderBy: { createdAt: "desc" },
      take: 5,
    }),
  ]);

  return (
    <div className="space-y-8">
      <div className="glass-card flex flex-wrap items-center justify-between gap-4 p-6">
        <div>
          <p className="text-sm text-ocean-500">
            {new Intl.DateTimeFormat("fr-FR", { weekday: "long", day: "numeric", month: "long" }).format(new Date())}
          </p>
          <h1 className="mt-1 font-display text-2xl font-bold text-ocean-900">
            Bonjour {user?.firstName} 👋
          </h1>
        </div>
        <span className="rounded-full px-4 py-1.5 text-xs font-semibold text-white" style={{ backgroundColor: user?.role.color }}>
          {user?.role.name}
        </span>
      </div>

      <div className="grid gap-6 sm:grid-cols-3">
        <div className="glass-card flex items-center gap-4 p-6">
          <span className="rounded-2xl bg-gradient-maree p-3 text-white"><CalendarDays size={20} /></span>
          <div>
            <p className="font-display text-2xl font-bold text-ocean-900">{upcomingEvents.length}</p>
            <p className="text-sm text-ocean-500">Événements à venir</p>
          </div>
        </div>
        <div className="glass-card flex items-center gap-4 p-6">
          <span className="rounded-2xl bg-gradient-maree p-3 text-white"><Bell size={20} /></span>
          <div>
            <p className="font-display text-2xl font-bold text-ocean-900">{notifications.length}</p>
            <p className="text-sm text-ocean-500">Notifications</p>
          </div>
        </div>
        <div className="glass-card flex items-center gap-4 p-6">
          <span className="rounded-2xl bg-gradient-maree p-3 text-white"><FileText size={20} /></span>
          <div>
            <p className="font-display text-2xl font-bold text-ocean-900">
              {user?.status === "PENDING" ? "1" : "0"}
            </p>
            <p className="text-sm text-ocean-500">Documents à compléter</p>
          </div>
        </div>
      </div>

      <div>
        <h2 className="mb-4 font-display text-lg font-bold text-ocean-900">Prochains événements</h2>
        {upcomingEvents.length > 0 ? (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {upcomingEvents.map((event) => (
              <EventCard key={event.id} event={event} />
            ))}
          </div>
        ) : (
          <div className="glass-card p-8 text-center text-ocean-500">Aucun événement à venir.</div>
        )}
      </div>
    </div>
  );
}
