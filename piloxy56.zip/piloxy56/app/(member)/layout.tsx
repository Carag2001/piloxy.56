import { MemberSidebar } from "@/components/layout/member-sidebar";

export default function MemberLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen bg-gradient-aube">
      <MemberSidebar />
      <main className="flex-1 p-6 lg:p-10">{children}</main>
    </div>
  );
}
