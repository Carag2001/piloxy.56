import { NextAuthOptions } from "next-auth";
import GoogleProvider from "next-auth/providers/google";
import CredentialsProvider from "next-auth/providers/credentials";
import bcrypt from "bcryptjs";
import { prisma } from "@/lib/prisma";

/**
 * Configuration centrale de l'authentification.
 *
 * Deux méthodes de connexion sont proposées :
 *  - Google OAuth (rapide, sans mot de passe)
 *  - Email + mot de passe (hashé avec bcrypt)
 *
 * La session est gérée en JWT (stateless, scalable) et enrichie
 * avec le rôle et l'identifiant interne de l'utilisateur.
 */
export const authOptions: NextAuthOptions = {
  session: {
    strategy: "jwt",
    maxAge: 30 * 24 * 60 * 60, // 30 jours
  },
  pages: {
    signIn: "/connexion",
    newUser: "/inscription",
  },
  providers: [
    GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID ?? "",
      clientSecret: process.env.GOOGLE_CLIENT_SECRET ?? "",
    }),
    CredentialsProvider({
      name: "Identifiants",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Mot de passe", type: "password" },
      },
      async authorize(credentials) {
        if (!credentials?.email || !credentials?.password) {
          throw new Error("Email et mot de passe requis.");
        }

        const user = await prisma.user.findUnique({
          where: { email: credentials.email.toLowerCase() },
          include: { role: true },
        });

        if (!user || !user.passwordHash) {
          throw new Error("Identifiants invalides.");
        }

        if (user.isSuspended) {
          throw new Error("Ce compte a été suspendu. Contactez l'association.");
        }

        const isValid = await bcrypt.compare(credentials.password, user.passwordHash);
        if (!isValid) {
          throw new Error("Identifiants invalides.");
        }

        await prisma.user.update({
          where: { id: user.id },
          data: { lastLoginAt: new Date() },
        });

        return {
          id: user.id,
          email: user.email,
          name: `${user.firstName} ${user.lastName}`,
          image: user.avatarUrl,
          role: user.role.slug,
        };
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.id = user.id;
        // @ts-expect-error - le champ role est ajouté dynamiquement dans authorize()
        token.role = user.role ?? "adherent";
      }
      return token;
    },
    async session({ session, token }) {
      if (session.user) {
        session.user.id = token.id as string;
        session.user.role = token.role as string;
      }
      return session;
    },
    async signIn({ user, account }) {
      // Pour les connexions Google, on crée automatiquement le compte
      // s'il n'existe pas encore, avec le rôle "Adhérent" par défaut.
      if (account?.provider === "google" && user.email) {
        const existing = await prisma.user.findUnique({ where: { email: user.email } });
        if (!existing) {
          const defaultRole = await prisma.role.findUnique({ where: { slug: "adherent" } });
          if (!defaultRole) return false;

          await prisma.user.create({
            data: {
              email: user.email,
              firstName: user.name?.split(" ")[0] ?? "Utilisateur",
              lastName: user.name?.split(" ").slice(1).join(" ") || "Google",
              googleId: user.id,
              avatarUrl: user.image,
              status: "ACTIVE",
              roleId: defaultRole.id,
            },
          });
        }
      }
      return true;
    },
  },
  secret: process.env.NEXTAUTH_SECRET,
};
