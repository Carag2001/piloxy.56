# 🌊 PILOXY 56

**Des jeunes, des idées, une énergie.**

Plateforme officielle de l'association PILOXY 56 (Morbihan, Bretagne) : site public + espace membre authentifié.

> Ce dépôt contient une **fondation réelle et fonctionnelle** de la plateforme : site public complet, authentification (email/mot de passe + Google), inscription aux événements, et tableau de bord membre. Elle est conçue pour être étendue module par module (back-office admin, comptabilité, gestion des mineurs, etc.) — voir [Prochaines étapes](#-prochaines-étapes).

## 🧱 Stack technique

- **Next.js 14** (App Router) + **TypeScript** strict
- **Tailwind CSS** (design system dédié, voir `tailwind.config.ts`)
- **Prisma ORM** + **PostgreSQL**
- **NextAuth.js** — connexion Email/mot de passe (bcrypt) + Google OAuth
- **Framer Motion** pour les animations
- **Zod** + **React Hook Form** pour la validation des formulaires
- **Lucide Icons**

## 🚀 Installation

### 1. Prérequis
- Node.js 18.18+ (recommandé : 20 LTS)
- Une base PostgreSQL (locale, [Supabase](https://supabase.com), ou [Neon](https://neon.tech))

### 2. Cloner et installer
```bash
git clone https://github.com/votre-compte/piloxy56.git
cd piloxy56
npm install
```

### 3. Configurer les variables d'environnement
```bash
cp .env.example .env
```
Renseignez dans `.env` :
- `DATABASE_URL` : votre chaîne de connexion PostgreSQL
- `NEXTAUTH_SECRET` : générez-le avec `openssl rand -base64 32`
- `GOOGLE_CLIENT_ID` / `GOOGLE_CLIENT_SECRET` : depuis la [Google Cloud Console](https://console.cloud.google.com/apis/credentials) (callback : `http://localhost:3000/api/auth/callback/google`)

### 4. Initialiser la base de données
```bash
npx prisma generate
npx prisma db push        # crée les tables
npm run db:seed           # crée les rôles, permissions et un compte Président de démo
```

Le seed crée un compte de connexion immédiat :
- **Email :** `president@piloxy56.fr`
- **Mot de passe :** `Piloxy56!2026`

⚠️ **Changez ce mot de passe dès la première connexion en production.**

### 5. Lancer le serveur de développement
```bash
npm run dev
```
Le site est disponible sur [http://localhost:3000](http://localhost:3000).

## 📁 Structure du projet

```
app/
  (public)/        → Site public (accueil, événements, actualités, contact...)
  (auth)/           → Connexion / inscription
  (member)/          → Espace membre protégé (tableau de bord)
  api/                → Routes API (auth, contact, événements, candidatures...)
components/
  layout/             → Header, footer, menu latéral membre
  sections/           → Sections de la page d'accueil (hero...)
  ui/                 → Composants réutilisables (cartes, compteurs...)
  forms/              → Formulaires (contact, connexion, inscription...)
lib/
  prisma.ts           → Client Prisma singleton
  auth.ts             → Configuration NextAuth
prisma/
  schema.prisma       → Schéma de base de données
  seed.ts             → Données initiales (rôles, permissions, démo)
```

## 🎨 Identité visuelle

Le design s'inspire de la côte du Morbihan (le "56") : bleu océan, vert algue, sable clair,
touches de jaune soleil. Glassmorphism, dégradés et animations Framer Motion dans tout le site.
Les tokens de couleur/typo sont centralisés dans `tailwind.config.ts`.

## 🔐 Sécurité déjà en place

- Mots de passe hashés avec **bcrypt** (12 rounds)
- Sessions **JWT** via NextAuth, cookies `HttpOnly`
- Validation stricte des entrées avec **Zod** sur toutes les routes API
- Middleware de protection des routes `/dashboard` et `/admin`
- Journal d'activité (`ActivityLog`) sur les actions sensibles

## 📦 Déploiement

Le plus simple : [Vercel](https://vercel.com) (créateur de Next.js).
1. Poussez ce dépôt sur GitHub (voir ci-dessous).
2. Importez-le sur Vercel.
3. Renseignez les mêmes variables d'environnement que dans `.env`.
4. Utilisez une base PostgreSQL managée (Supabase, Neon, Vercel Postgres).

## 📤 Mettre ce projet sur GitHub

```bash
cd piloxy56
git init
git add .
git commit -m "Initial commit — PILOXY 56"
git branch -M main
git remote add origin https://github.com/votre-compte/piloxy56.git
git push -u origin main
```

## 🗺️ Prochaines étapes

Cette base couvre le socle **site public + authentification + espace membre**. Le cahier des
charges complet prévoit aussi, module par module :
- Back-office administrateur complet (utilisateurs, rôles, permissions granulaires, statistiques)
- Gestion documentaire (dossiers, versionning)
- Galerie photo/vidéo avec albums
- Comptabilité interne (recettes, dépenses, subventions)
- Registre des mineurs et autorisations parentales
- Registre des incidents
- Notifications en temps réel

Le schéma Prisma (`prisma/schema.prisma`) est déjà structuré pour accueillir ces extensions
sans rupture de compatibilité (tables `Minor`, `Parent`, `Document`, `GalleryItem`, `Album`,
`ActivityLog`, etc. déjà présentes).

---

© PILOXY 56 — Association loi 1901, Morbihan, Bretagne.
