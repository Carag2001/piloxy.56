import type { Config } from "tailwindcss";

// ─────────────────────────────────────────────────────────────
// Identité visuelle PILOXY 56
// Inspirée de la côte du Morbihan (le "56") : océan, algues, sable, soleil d'été.
// ─────────────────────────────────────────────────────────────
const config: Config = {
  darkMode: "class",
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        ocean: {
          50: "#EAF7FA",
          100: "#CDEDF3",
          200: "#9CDBE8",
          300: "#65C3D6",
          400: "#38A9C0",
          500: "#0C7C92", // bleu principal
          600: "#0A6577",
          700: "#0A4F5D",
          800: "#0B3D48",
          900: "#0B2B33", // nuit / texte
        },
        algue: {
          50: "#EAFBF3",
          100: "#CDF4E1",
          200: "#9CE7C4",
          300: "#63D5A2",
          400: "#3FBE86",
          500: "#1F8A5F", // vert principal
          600: "#186F4C",
          700: "#14573D",
          800: "#12432F",
          900: "#0F3627",
        },
        sable: {
          50: "#FFFEFC",
          100: "#FBF9F2", // fond clair
          200: "#F5F0E3",
          300: "#EDE4CE",
        },
        soleil: {
          200: "#FFF3CF",
          300: "#FFE8A3",
          400: "#FFD666", // jaune léger, touche uniquement
          500: "#F7C331",
        },
      },
      fontFamily: {
        display: ["var(--font-display)", "sans-serif"],
        body: ["var(--font-body)", "sans-serif"],
      },
      backgroundImage: {
        "gradient-maree": "linear-gradient(135deg, #0C7C92 0%, #1F8A5F 100%)",
        "gradient-aube": "linear-gradient(180deg, #EAF7FA 0%, #FBF9F2 100%)",
        "gradient-soleil": "radial-gradient(circle at 30% 30%, #FFE8A3 0%, transparent 60%)",
      },
      boxShadow: {
        glass: "0 8px 32px 0 rgba(11, 43, 51, 0.12)",
        "glass-lg": "0 20px 60px -10px rgba(11, 43, 51, 0.25)",
        glow: "0 0 40px -5px rgba(63, 190, 134, 0.45)",
      },
      borderRadius: {
        "4xl": "2rem",
        "5xl": "2.5rem",
      },
      keyframes: {
        "wave-drift": {
          "0%, 100%": { transform: "translateX(0) translateY(0)" },
          "50%": { transform: "translateX(-2%) translateY(1%)" },
        },
        float: {
          "0%, 100%": { transform: "translateY(0px)" },
          "50%": { transform: "translateY(-12px)" },
        },
        "fade-up": {
          "0%": { opacity: "0", transform: "translateY(24px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        shimmer: {
          "0%": { backgroundPosition: "-200% 0" },
          "100%": { backgroundPosition: "200% 0" },
        },
      },
      animation: {
        "wave-drift": "wave-drift 8s ease-in-out infinite",
        float: "float 6s ease-in-out infinite",
        "fade-up": "fade-up 0.8s cubic-bezier(0.16, 1, 0.3, 1) forwards",
        shimmer: "shimmer 2.5s linear infinite",
      },
    },
  },
  plugins: [require("@tailwindcss/typography")],
};

export default config;
